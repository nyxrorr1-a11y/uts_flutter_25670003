import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const SeminarApp());

class SeminarApp extends StatelessWidget {
  const SeminarApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pendaftaran Seminar',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF3949AB)),
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(8)),
          ),
        ),
      ),
      home: const RegistrationPage(),
    );
  }
}

class RegistrationPage extends StatefulWidget {
  const RegistrationPage({super.key});

  @override
  State<RegistrationPage> createState() => _RegistrationPageState();
}

class _RegistrationPageState extends State<RegistrationPage> {
  // GlobalKey untuk mengakses & memvalidasi form
  final _formKey = GlobalKey<FormState>();

  // Controller untuk membaca nilai input
  final _namaCtrl = TextEditingController();
  final _nimCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _tanggalCtrl = TextEditingController();
  final _catatanCtrl = TextEditingController();

  bool _obscure = true;
  String? _gender;
  DateTime? _tanggal;
  String? _prodi;
  bool _setuju = false;

  final Map<String, bool> _hobi = {
    'Membaca': false,
    'Musik': false,
    'Olahraga': false,
    'Fotografi': false,
  };

  final List<String> _prodiList = [
    'Pendidikan TI',
    'Teknologi Digital',
    'Teknik Informatika',
    'Sistem Informasi',
  ];

  @override
  void dispose() {
    _namaCtrl.dispose();
    _nimCtrl.dispose();
    _emailCtrl.dispose();
    _passCtrl.dispose();
    _tanggalCtrl.dispose();
    _catatanCtrl.dispose();
    super.dispose();
  }

  // ---------- Date picker ----------
  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _tanggal ?? now,
      firstDate: now,
      lastDate: DateTime(now.year + 1, now.month, now.day),
    );
    if (picked != null) {
      setState(() {
        _tanggal = picked;
        _tanggalCtrl.text =
            '${picked.day.toString().padLeft(2, '0')}/${picked.month.toString().padLeft(2, '0')}/${picked.year}';
      });
    }
  }

  // ---------- Simpan ----------
  void _submit() {
    if (_formKey.currentState!.validate()) {
      _showSummary();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Periksa kembali data yang belum sesuai.')),
      );
    }
  }

  void _resetForm() {
    _formKey.currentState!.reset();
    _namaCtrl.clear();
    _nimCtrl.clear();
    _emailCtrl.clear();
    _passCtrl.clear();
    _tanggalCtrl.clear();
    _catatanCtrl.clear();
    setState(() {
      _gender = null;
      _tanggal = null;
      _prodi = null;
      _setuju = false;
      _obscure = true;
      _hobi.updateAll((key, value) => false);
    });
  }

  // ---------- Ringkasan data (dialog) ----------
  void _showSummary() {
    final hobiDipilih =
        _hobi.entries.where((e) => e.value).map((e) => e.key).join(', ');

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        icon: const Icon(Icons.check_circle, color: Colors.green, size: 48),
        title: const Text('Pendaftaran Berhasil'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _row('Nama', _namaCtrl.text.trim()),
              _row('NIM', _nimCtrl.text),
              _row('Email', _emailCtrl.text.trim()),
              _row('Password', '•' * _passCtrl.text.length),
              _row('Jenis Kelamin', _gender ?? '-'),
              _row('Hobi', hobiDipilih),
              _row('Program Studi', _prodi ?? '-'),
              _row('Tanggal Seminar', _tanggalCtrl.text),
              _row('Catatan',
                  _catatanCtrl.text.trim().isEmpty ? '-' : _catatanCtrl.text.trim()),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              _resetForm();
            },
            child: const Text('Isi Formulir Baru'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }

  Widget _row(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 110,
              child: Text(label,
                  style: const TextStyle(fontWeight: FontWeight.bold)),
            ),
            const Text(': '),
            Expanded(child: Text(value)),
          ],
        ),
      );

  Widget _sectionTitle(String text, {String? sub}) => Padding(
        padding: const EdgeInsets.only(top: 8, bottom: 4),
        child: Row(
          children: [
            Text(text,
                style: const TextStyle(
                    fontWeight: FontWeight.bold, fontSize: 15)),
            if (sub != null)
              Text('  $sub',
                  style: TextStyle(
                      fontSize: 12, color: Theme.of(context).colorScheme.primary)),
          ],
        ),
      );

  // ---------- UI ----------
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: cs.primary,
        foregroundColor: cs.onPrimary,
        title: const Text('Pendaftaran Seminar'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: cs.primaryContainer,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.mic, size: 40, color: cs.primary),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Formulir Pendaftaran',
                                style: TextStyle(
                                    fontSize: 18, fontWeight: FontWeight.bold)),
                            Text(
                                'Seminar Nasional Teknologi & Inovasi Digital di Era Globalisasi'),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // Nama lengkap
                TextFormField(
                  controller: _namaCtrl,
                  textCapitalization: TextCapitalization.words,
                  decoration: const InputDecoration(
                    labelText: 'Nama Lengkap',
                    hintText: 'Masukkan nama lengkap',
                    prefixIcon: Icon(Icons.person),
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Nama wajib diisi';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                // NIM
                TextFormField(
                  controller: _nimCtrl,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  decoration: const InputDecoration(
                    labelText: 'NIM',
                    hintText: 'Minimal 8 digit angka',
                    prefixIcon: Icon(Icons.badge),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'NIM wajib diisi';
                    }
                    if (!RegExp(r'^\d+$').hasMatch(value)) {
                      return 'NIM harus berupa angka';
                    }
                    if (value.length < 8) {
                      return 'NIM minimal 8 digit';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                // Email
                TextFormField(
                  controller: _emailCtrl,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(
                    labelText: 'Email',
                    hintText: 'nama@email.com',
                    prefixIcon: Icon(Icons.email),
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Email wajib diisi';
                    }
                    final regex =
                        RegExp(r'^[\w\.\-]+@([\w\-]+\.)+[\w\-]{2,}$');
                    if (!regex.hasMatch(value.trim())) {
                      return 'Format email tidak valid';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                // Password
                TextFormField(
                  controller: _passCtrl,
                  obscureText: _obscure,
                  decoration: InputDecoration(
                    labelText: 'Password',
                    hintText: 'Masukkan password',
                    prefixIcon: const Icon(Icons.lock),
                    suffixIcon: IconButton(
                      icon: Icon(
                          _obscure ? Icons.visibility : Icons.visibility_off),
                      onPressed: () => setState(() => _obscure = !_obscure),
                    ),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Password wajib diisi';
                    }
                    if (value.length < 8) {
                      return 'Password minimal 8 karakter';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                // Jenis kelamin (Radio)
                _sectionTitle('Jenis Kelamin'),
                FormField<String>(
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  validator: (_) =>
                      _gender == null ? 'Pilih jenis kelamin' : null,
                  builder: (state) => Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      for (final g in ['Laki-laki', 'Perempuan'])
                        RadioListTile<String>(
                          dense: true,
                          contentPadding: EdgeInsets.zero,
                          title: Text(g),
                          value: g,
                          groupValue: _gender,
                          onChanged: (v) {
                            setState(() => _gender = v);
                            state.didChange(v);
                          },
                        ),
                      if (state.hasError) _errorText(state.errorText!),
                    ],
                  ),
                ),

                // Hobi (Checkbox)
                _sectionTitle('Hobi', sub: '(boleh lebih dari satu)'),
                FormField<bool>(
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  validator: (_) => _hobi.values.any((v) => v)
                      ? null
                      : 'Pilih minimal satu hobi',
                  builder: (state) => Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      for (final key in _hobi.keys)
                        CheckboxListTile(
                          dense: true,
                          contentPadding: EdgeInsets.zero,
                          controlAffinity: ListTileControlAffinity.leading,
                          title: Text(key),
                          value: _hobi[key],
                          onChanged: (v) {
                            setState(() => _hobi[key] = v ?? false);
                            state.didChange(true);
                          },
                        ),
                      if (state.hasError) _errorText(state.errorText!),
                    ],
                  ),
                ),
                const SizedBox(height: 8),

                // Program studi (Dropdown)
                DropdownButtonFormField<String>(
                  initialValue: _prodi,
                  decoration: const InputDecoration(
                    labelText: 'Program Studi',
                    prefixIcon: Icon(Icons.school),
                  ),
                  items: _prodiList
                      .map((p) => DropdownMenuItem(value: p, child: Text(p)))
                      .toList(),
                  onChanged: (v) => setState(() => _prodi = v),
                  validator: (value) =>
                      value == null ? 'Program studi wajib dipilih' : null,
                ),
                const SizedBox(height: 16),

                // Tanggal seminar (Date picker)
                TextFormField(
                  controller: _tanggalCtrl,
                  readOnly: true,
                  onTap: _pickDate,
                  decoration: const InputDecoration(
                    labelText: 'Tanggal Seminar',
                    hintText: 'Pilih tanggal',
                    prefixIcon: Icon(Icons.event),
                    suffixIcon: Icon(Icons.calendar_today),
                  ),
                  validator: (value) => (value == null || value.isEmpty)
                      ? 'Tanggal seminar wajib dipilih'
                      : null,
                ),
                const SizedBox(height: 16),

                // Catatan (Text area)
                TextFormField(
                  controller: _catatanCtrl,
                  maxLines: 4,
                  decoration: const InputDecoration(
                    labelText: 'Catatan (opsional)',
                    hintText: 'Contoh: butuh obat untuk penyakit khusus, pertanyaan untuk pembicara...',
                    alignLabelWithHint: true,
                  ),
                  validator: (value) {
                    if (value != null && value.length > 200) {
                      return 'Catatan maksimal 200 karakter';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 8),

                // Syarat & ketentuan
                FormField<bool>(
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  validator: (_) => _setuju
                      ? null
                      : 'Anda harus menyetujui syarat dan ketentuan',
                  builder: (state) => Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CheckboxListTile(
                        contentPadding: EdgeInsets.zero,
                        controlAffinity: ListTileControlAffinity.leading,
                        title: const Text('Saya menyetujui syarat dan ketentuan'),
                        value: _setuju,
                        onChanged: (v) {
                          setState(() => _setuju = v ?? false);
                          state.didChange(_setuju);
                        },
                      ),
                      if (state.hasError) _errorText(state.errorText!),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // Tombol Simpan
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: FilledButton.icon(
                    onPressed: _submit,
                    icon: const Icon(Icons.send),
                    label: const Text('Simpan'),
                  ),
                ),
                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ),
    );
  }
 
  Widget _errorText(String msg) => Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 4),
        child: Text(
          msg,
          style: TextStyle(
              color: Theme.of(context).colorScheme.error, fontSize: 12),
        ),
      );
}