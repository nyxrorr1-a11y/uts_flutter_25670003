package com.example.flutter_application_kb

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
